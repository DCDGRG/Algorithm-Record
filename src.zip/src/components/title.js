import React from "react";

function title({title}) {
  return (
    <div>
      <h2>{title}</h2>
    </div>
    
  );
}   

export default title;
